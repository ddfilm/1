<?php
session_start();
require_once 'includes/config.php';

// تابع تبدیل تاریخ میلادی به شمسی
function gregorian_to_jalali($gy, $gm, $gd) {
    $g_d_m = array(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334);
    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
    $days = 355666 + (365 * $gy) + ((int)(($gy2 + 3) / 4)) - ((int)(($gy2 + 99) / 100)) + ((int)(($gy2 + 399) / 400)) + $gd + $g_d_m[$gm - 1];
    $jy = -1595 + (33 * ((int)($days / 12053)));
    $days %= 12053;
    $jy += 4 * ((int)($days / 1461));
    $days %= 1461;
    if ($days > 365) {
        $jy += (int)(($days - 1) / 365);
        $days = ($days - 1) % 365;
    }
    $jm = ($days < 186) ? 1 + (int)($days / 31) : 7 + (int)(($days - 186) / 30);
    $jd = 1 + (($days < 186) ? ($days % 31) : (($days - 186) % 30));
    return array($jy, $jm, $jd);
}

function format_jalali_date($date) {
    if (empty($date)) return 'تاریخ نامعلوم';
    $date = strtotime($date);
    list($year, $month, $day) = gregorian_to_jalali(date('Y', $date), date('n', $date), date('j', $date));
    return sprintf('%04d/%02d/%02d', $year, $month, $day);
}

// بررسی لاگین کاربر
if (!isset($_SESSION['user_id'])) {
    header("Location: login/");
    exit();
}

// دریافت اطلاعات کاربر
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT username, email, created_at FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($username, $email, $join_date);
$stmt->fetch();
$stmt->close();

// مقادیر پیش‌فرض برای آمار
$games_played = 0;
$total_score = 0;
$best_score = 0;
$average_score = 0;
$last_games = [];
$overall_percentage = 0;

// بررسی وجود جدول game_results
$table_exists = false;
$table_check = $conn->query("SHOW TABLES LIKE 'game_results'");
if ($table_check && $table_check->num_rows > 0) {
    $table_exists = true;
    
    // دریافت آمار کلی کاربر
    $stmt = $conn->prepare("SELECT COUNT(*) as count, SUM(score) as total, MAX(score) as best FROM game_results WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($games_played, $total_score, $best_score);
    $stmt->fetch();
    $stmt->close();

    // محاسبه میانگین امتیاز
    if ($games_played > 0) {
        $average_score = round($total_score / $games_played);
        $overall_percentage = min(100, round(($total_score / ($games_played * 40 * 10)) * 100)); // محدود کردن به حداکثر 100%
    }

    // دریافت ۵ بازی اخیر
    $stmt = $conn->prepare("SELECT score, question_count, created_at FROM game_results WHERE user_id = ? ORDER BY created_at DESC LIMIT 5");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($score, $question_count, $game_date);

    while ($stmt->fetch()) {
        $percentage = ($question_count > 0) ? min(100, round(($score / ($question_count * 40)) * 100)) : 0; // محدود کردن به حداکثر 100%
        $last_games[] = [
            'score' => $score,
            'count' => $question_count,
            'date' => format_jalali_date($game_date),
            'percentage' => $percentage
        ];
    }
    $stmt->close();
}

// تبدیل تاریخ عضویت به شمسی
$join_date_jalali = format_jalali_date($join_date);
?>

<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>پنل کاربری - <?php echo htmlspecialchars($username); ?> | سینمازمون</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #6e48aa;
            --secondary-color: #9d50bb;
            --accent-color: #ff6b6b;
            --logout-color: #f44336;
            --gold-color: #FFD700;
            --dark-color: #333;
            --light-color: #f8f9fc;
        }
        
        body {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            font-family: 'Vazir', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            min-height: 100vh;
        }
        
        .dashboard-container {
            max-width: 1200px;
            margin: 20px auto;
            background: rgba(0, 0, 0, 0.7);
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
            position: relative;
        }
        
        .logout-btn {
            position: absolute;
            left: 20px;
            top: 20px;
            background: var(--logout-color);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 50px;
            font-size: 0.9rem;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .logout-btn:hover {
            background: #d32f2f;
            transform: scale(1.05);
        }
        
        .welcome-section {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .welcome-section h1 {
            margin: 0;
            font-size: 2rem;
            color: var(--gold-color);
        }
        
        .welcome-section p {
            margin: 5px 0 0;
            opacity: 0.8;
        }
        
        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            transition: transform 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-card i {
            font-size: 2.5rem;
            margin-bottom: 10px;
            color: var(--gold-color);
        }
        
        .stat-card h3 {
            margin: 0 0 10px;
            font-size: 1.2rem;
        }
        
        .stat-card p {
            margin: 0;
            font-size: 1.8rem;
            font-weight: bold;
        }
        
        .recent-games {
            background: rgba(0, 0, 0, 0.5);
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .recent-games h2 {
            margin-top: 0;
            color: var(--gold-color);
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            padding-bottom: 10px;
        }
        
        .game-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .game-item:last-child {
            border-bottom: none;
        }
        
        .game-date {
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.9rem;
        }
        
        .game-score {
            font-weight: bold;
            color: var(--gold-color);
        }
        
        .start-game-btn {
            display: block;
            width: 100%;
            background: var(--accent-color);
            color: white;
            border: none;
            padding: 15px;
            border-radius: 50px;
            font-size: 1.2rem;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            transition: all 0.3s;
            margin-top: 20px;
        }
        
        .start-game-btn:hover {
            background: #ff8e8e;
            transform: scale(1.02);
        }
        
        .percentage-circle {
            width: 120px;
            height: 120px;
            margin: 0 auto 20px;
            border-radius: 50%;
            background: conic-gradient(var(--gold-color) var(--percentage), #333 var(--percentage));
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            font-weight: bold;
        }
        
        .percentage-text {
            background: rgba(0, 0, 0, 0.7);
            width: 90px;
            height: 90px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .no-data-message {
            text-align: center;
            padding: 20px;
            color: var(--gold-color);
            font-size: 1.1rem;
        }
        
        .data-status {
            text-align: center;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        
        .data-status.warning {
            background-color: rgba(255, 193, 7, 0.2);
            color: #ffc107;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- دکمه خروج -->
        <a href="logout.php" class="logout-btn">
            <i class="fas fa-sign-out-alt"></i>
            خروج
        </a>
        
        <div class="welcome-section">
            <h1>سلام <?php echo htmlspecialchars($username); ?>! 👋</h1>
            <p>به پنل کاربری سینمازمون خوش آمدید</p>
            
            <?php if ($table_exists && $games_played > 0): ?>
                <div class="percentage-circle" style="--percentage: <?php echo $overall_percentage; ?>%">
                    <div class="percentage-text">
                        <?php echo $overall_percentage; ?>%
                    </div>
                </div>
            <?php else: ?>
                <div class="percentage-circle" style="--percentage: 0%">
                    <div class="percentage-text">
                        0%
                    </div>
                </div>
            <?php endif; ?>
        </div>
        
        <?php if (!$table_exists): ?>
            <div class="data-status warning">
                <i class="fas fa-exclamation-triangle"></i> سیستم آماری در حال حاضر فعال نیست
            </div>
        <?php endif; ?>
        
        <div class="stats-cards">
            <div class="stat-card">
                <i class="fas fa-gamepad"></i>
                <h3>تعداد بازی‌ها</h3>
                <p><?php echo $games_played; ?></p>
            </div>
            
            <div class="stat-card">
                <i class="fas fa-star"></i>
                <h3>میانگین امتیاز</h3>
                <p><?php echo $average_score; ?></p>
            </div>
            
            <div class="stat-card">
                <i class="fas fa-trophy"></i>
                <h3>بالاترین امتیاز</h3>
                <p><?php echo $best_score; ?></p>
            </div>
            
            <div class="stat-card">
                <i class="fas fa-calendar-alt"></i>
                <h3>عضو شده از</h3>
                <p><?php echo $join_date_jalali; ?></p>
            </div>
        </div>
        
        <div class="recent-games">
            <h2><i class="fas fa-history"></i> بازی‌های اخیر</h2>
            
            <?php if (!empty($last_games)): ?>
                <?php foreach ($last_games as $game): ?>
                <div class="game-item">
                    <span class="game-date"><?php echo $game['date']; ?></span>
                    <span class="game-score"><?php echo $game['score']; ?> از <?php echo $game['count'] * 40; ?> (<?php echo $game['percentage']; ?>%)</span>
                </div>
                <?php endforeach; ?>
            <?php elseif ($table_exists): ?>
                <p class="no-data-message">هنوز بازی‌ای انجام نداده‌اید!</p>
            <?php else: ?>
                <p class="no-data-message">سیستم آماری در دسترس نیست</p>
            <?php endif; ?>
        </div>
        
        <a href="../index.php" class="start-game-btn">
            <i class="fas fa-play"></i> شروع بازی جدید
        </a>
    </div>
    
    <!-- اضافه کردن فونت وزیر برای نمایش بهتر فارسی -->
    <link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazir-font@v30.1.0/dist/font-face.css" rel="stylesheet" type="text/css" />
</body>
</html>
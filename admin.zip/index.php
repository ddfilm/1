<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>سینمازمون | بازی کوییز فیلمی</title>
    <style>
        * {
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #6e48aa, #9d50bb);
            color: white;
            padding: 20px;
            margin: 0;
            min-height: 100vh;
        }
        
        .container {
            max-width: 600px;
            margin: 0 auto;
            background: rgba(0, 0, 0, 0.7);
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
        }

        button {
            background: #ff6b6b;
            color: white;
            border: none;
            padding: 12px 20px;
            margin: 10px 0;
            border-radius: 50px;
            cursor: pointer;
            width: 100%;
            font-size: 16px;
            transition: all 0.3s;
        }
        
        button:hover {
            background: #ff8e8e;
            transform: scale(1.02);
        }
        
        .hidden {
            display: none;
        }
        
        #options button.correct {
            background: #4CAF50 !important;
            animation: pulse 0.5s;
        }
        
        #options button.wrong {
            background: #f44336 !important;
            animation: shake 0.5s;
        }

        #timer {
            font-size: 18px;
            margin: 10px 0;
            text-align: center;
            color: #FFD700;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            75% { transform: translateX(5px); }
        }

        .question-text {
            font-size: 18px;
            text-align: center;
            margin-bottom: 10px;
        }

        .question-counter {
            font-size: 14px;
            text-align: center;
            color: #FFD700;
            margin-bottom: 15px;
        }

        #end-screen {
            text-align: center;
        }

        #final-message {
            font-size: 24px;
            margin: 20px 0;
            color: #FFD700;
        }

        /* استایل‌های جدید برای تنظیمات */
        .setting-group {
            margin: 20px 0;
            padding: 15px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
        }

        .setting-title {
            font-size: 18px;
            margin-bottom: 10px;
            color: #FFD700;
            text-align: center;
        }

        .options-container {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 10px;
        }

        .option-btn {
            padding: 10px 15px;
            border-radius: 50px;
            background: rgba(255, 255, 255, 0.2);
            cursor: pointer;
            transition: all 0.3s;
        }

        .option-btn.selected {
            background: #ff6b6b;
            font-weight: bold;
        }

        /* استایل‌های جدید برای صفحه نام کاربری */
        #name-input {
            width: 100%;
            padding: 12px 20px;
            border-radius: 50px;
            border: none;
            margin: 10px 0;
            text-align: center;
            font-size: 16px;
            background: rgba(255, 255, 255, 0.9);
        }

        /* استایل‌های جدید برای اشتراک گذاری */
        .share-buttons {
            display: flex;
            gap: 10px;
            margin: 20px 0;
        }

        .share-btn {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 10px;
            border-radius: 50px;
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .telegram {
            background: #0088cc;
        }

        .whatsapp {
            background: #25D366;
        }

        .twitter {
            background: #1DA1F2;
        }

        /* استایل‌های جدید برای رتبه بندی */
        #leaderboard {
            margin-top: 20px;
            border-top: 1px solid #444;
            padding-top: 20px;
        }

        .leaderboard-item {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #333;
        }

        .percentage-circle {
            width: 120px;
            height: 120px;
            margin: 20px auto;
            border-radius: 50%;
            background: conic-gradient(#4CAF50 var(--percentage), #333 var(--percentage));
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            font-weight: bold;
        }

        .percentage-text {
            background: rgba(0, 0, 0, 0.7);
            width: 90px;
            height: 90px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* استایل‌های جدید برای تصاویر سوالات */
        #question-image {
            max-width: 100%;
            height: auto;
            border-radius: 10px;
            margin: 10px auto;
            display: none;
            max-height: 200px;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- صفحه نام کاربری -->
        <div id="name-screen">
            <h1 style="text-align: center;">🎬 سینمازمون</h1>
            <input type="text" id="name-input" placeholder="نام خود را وارد کنید" maxlength="20">
            <button onclick="showSettings()">ادامه</button>
        </div>

        <!-- صفحه تنظیمات -->
        <div id="settings-screen" class="hidden">
            <h1 style="text-align: center;">تنظیمات بازی</h1>
            
            <div class="setting-group">
                <div class="setting-title">تعداد سوالات</div>
                <div class="options-container">
                    <div class="option-btn selected" onclick="selectQuestionCount(this, 10)">10 سوال</div>
                    <div class="option-btn" onclick="selectQuestionCount(this, 15)">15 سوال</div>
                    <div class="option-btn" onclick="selectQuestionCount(this, 20)">20 سوال</div>
                </div>
            </div>
            
            <div class="setting-group">
                <div class="setting-title">دسته‌بندی سوالات</div>
                <div class="options-container">
                    <div class="option-btn selected" onclick="selectCategory(this, 'all')">همه دسته‌ها</div>
                    <div class="option-btn" onclick="selectCategory(this, 'iran')">سینمای ایران</div>
                    <div class="option-btn" onclick="selectCategory(this, 'foreign')">سینمای خارج</div>
                </div>
            </div>
            
            <button onclick="startGame()">شروع بازی</button>
        </div>

        <!-- صفحه بازی -->
        <div id="game-screen" class="hidden">
            <div id="timer">زمان باقیمانده: 15 ثانیه | امتیاز احتمالی: 40</div>
            <div id="question-container">
                <div id="question-counter" class="question-counter"></div>
                <div id="question-text" class="question-text"></div>
                <img id="question-image" src="" alt="تصویر سوال">
            </div>
            <div id="options"></div>
            <div id="score">امتیاز: 0</div>
        </div>

        <!-- صفحه پایان بازی -->
        <div id="end-screen" class="hidden">
            <h1 style="text-align: center;">🎬 نتایج بازی</h1>
            
            <div class="percentage-circle" id="percentage-circle">
                <div class="percentage-text" id="percentage-text">0%</div>
            </div>
            
            <div id="final-score">امتیاز نهایی شما: 0 از 0</div>
            <div id="final-message"></div>
            
            <div class="share-buttons">
                <a href="#" id="telegram-share" class="share-btn telegram" target="_blank">
                    <span>اشتراک در تلگرام</span>
                </a>
                <a href="#" id="whatsapp-share" class="share-btn whatsapp" target="_blank">
                    <span>اشتراک در واتساپ</span>
                </a>
                <a href="#" id="twitter-share" class="share-btn twitter" target="_blank">
                    <span>اشتراک در توییتر</span>
                </a>
            </div>
            
            <div id="leaderboard">
                <h3>بهترین امتیازها</h3>
                <div id="leaderboard-list"></div>
            </div>
            
            <button onclick="restartGame()">بازی مجدد</button>
        </div>
    </div>

    <script>
        // بانک سوالات (ابتدا خالی، سپس از سرور بارگذاری می‌شود)
        let allQuestions = [];

        // متغیرهای بازی
        let currentScore = 0;
        let currentQuestionIndex = 0;
        let timer;
        let timeLeft;
        let selectedQuestions = [];
        let selectedQuestionCount = 10;
        let selectedCategory = "all";
        let playerName = "";
        let leaderboard = JSON.parse(localStorage.getItem('cinemaQuizLeaderboard')) || [];

        // بارگذاری سوالات از سرور
        fetch('admin/questions.json')
            .then(response => response.json())
            .then(data => {
                allQuestions = data;
                console.log('سوالات با موفقیت بارگذاری شدند');
            })
            .catch(error => {
                console.error('خطا در بارگذاری سوالات:', error);
                // استفاده از سوالات پیش‌فرض در صورت خطا
                allQuestions = [
                    {
                        question: "کارگردان فیلم «فروشنده» کیست؟",
                        options: ["اصغر فرهادی", "بهروز افخمی", "مسعود کیمیایی", "ناصر تقوایی"],
                        answer: 0,
                        category: "iran",
                        image: "pic/forushande.jpg"
                    },
                    {
                        question: "فیلم «شیرین» محصول کدام کشور است؟",
                        options: ["ترکیه", "ایران", "فرانسه", "آمریکا"],
                        answer: 1,
                        category: "iran"
                    },
                    {
                        question: "کارگردان فیلم «پاراسایت» کیست؟",
                        options: ["کریستوفر نولان", "بونگ جون هو", "مارتین اسکورسیزی", "کوئنتین تارانتینو"],
                        answer: 1,
                        category: "foreign",
                        image: "pic/parasite.jpg"
                    },
                    {
                        question: "کدام فیلم بر اساس رمانی از استیون کینگ ساخته شده است؟",
                        options: ["مسیر سبز", "پدرخوانده", "مرد مرده", "بلید رانر"],
                        answer: 0,
                        category: "all"
                    }
                ];
            });

        // توابع بازی
        function showSettings() {
            const name = document.getElementById("name-input").value.trim();
            if (name === "") {
                alert("لطفاً نام خود را وارد کنید");
                return;
            }
            playerName = name;
            document.getElementById("name-screen").classList.add("hidden");
            document.getElementById("settings-screen").classList.remove("hidden");
        }

        function selectQuestionCount(button, count) {
            selectedQuestionCount = count;
            const buttons = button.parentElement.querySelectorAll('.option-btn');
            buttons.forEach(btn => btn.classList.remove('selected'));
            button.classList.add('selected');
        }

        function selectCategory(button, category) {
            selectedCategory = category;
            const buttons = button.parentElement.querySelectorAll('.option-btn');
            buttons.forEach(btn => btn.classList.remove('selected'));
            button.classList.add('selected');
        }

        function startGame() {
            currentScore = 0;
            currentQuestionIndex = 0;
            
            let filteredQuestions = selectedCategory === "all" 
                ? allQuestions 
                : allQuestions.filter(q => q.category === selectedCategory);
            
            // اگر تعداد سوالات درخواستی بیشتر از سوالات موجود باشد
            const actualCount = Math.min(selectedQuestionCount, filteredQuestions.length);
            selectedQuestions = getRandomQuestions(actualCount, filteredQuestions);
            
            document.getElementById("settings-screen").classList.add("hidden");
            document.getElementById("game-screen").classList.remove("hidden");
            
            startTimer();
            showQuestion();
        }

        function getRandomQuestions(count, questions) {
            return [...questions].sort(() => 0.5 - Math.random()).slice(0, count);
        }

        function startTimer() {
            timeLeft = 15;
            updateTimerDisplay();
            
            clearInterval(timer);
            timer = setInterval(() => {
                timeLeft--;
                updateTimerDisplay();
                
                if(timeLeft <= 0) {
                    clearInterval(timer);
                    timeUp();
                }
            }, 1000);
        }

        function updateTimerDisplay() {
            const potentialScore = 10 + (timeLeft * 2);
            document.getElementById("timer").textContent = 
                `زمان باقیمانده: ${timeLeft} ثانیه | امتیاز احتمالی: ${potentialScore}`;
        }

        function showQuestion() {
            const question = selectedQuestions[currentQuestionIndex];
            document.getElementById("question-text").textContent = question.question;
            document.getElementById("question-counter").textContent = 
                `سوال ${currentQuestionIndex + 1} از ${selectedQuestions.length}`;
            
            // نمایش تصویر سوال اگر وجود داشته باشد
            const questionImage = document.getElementById("question-image");
            if (question.image) {
                questionImage.src = question.image;
                questionImage.style.display = "block";
            } else {
                questionImage.style.display = "none";
            }
            
            let optionsHTML = "";
            question.options.forEach((option, index) => {
                optionsHTML += `<button onclick="checkAnswer(${index}, ${question.answer})">${option}</button>`;
            });
            
            document.getElementById("options").innerHTML = optionsHTML;
            document.getElementById("score").textContent = `امتیاز: ${currentScore}`;
        }

        function checkAnswer(selectedIndex, correctAnswer) {
            clearInterval(timer);
            const buttons = document.querySelectorAll("#options button");
            const correctSound = new Audio('sound/correct.mp3');
            const wrongSound = new Audio('sound/wrong.mp3');
            
            buttons[correctAnswer].classList.add("correct");
            
            const timeBonus = Math.floor(timeLeft * 2);
            const baseScore = 10;
            const totalScore = baseScore + timeBonus;
            
            if (selectedIndex === correctAnswer) {
                correctSound.play();
                currentScore += totalScore;
                document.getElementById("score").textContent = `امتیاز: ${currentScore} (+${totalScore})`;
            } else {
                wrongSound.play();
                buttons[selectedIndex].classList.add("wrong");
                document.getElementById("score").textContent = `امتیاز: ${currentScore} (۰+)`;
            }
            
            buttons.forEach(btn => btn.disabled = true);
            
            setTimeout(() => {
                currentQuestionIndex++;
                if (currentQuestionIndex < selectedQuestions.length) {
                    showQuestion();
                    startTimer();
                } else {
                    endGame();
                }
            }, 1500);
        }

        function endGame() {
            document.getElementById("game-screen").classList.add("hidden");
            document.getElementById("end-screen").classList.remove("hidden");
            
            const maxScore = selectedQuestions.length * 40;
            const percentage = Math.round((currentScore / maxScore) * 100);
            
            document.getElementById("final-score").textContent = 
                `امتیاز نهایی ${playerName}: ${currentScore} از ${maxScore}`;
            
            document.getElementById("percentage-circle").style.setProperty('--percentage', `${percentage}%`);
            document.getElementById("percentage-text").textContent = `${percentage}%`;
            
            let message = "";
            if (percentage >= 90) message = "شما یک نابغه سینما هستید! 🎬🏆";
            else if (percentage >= 70) message = "عالی! دانش سینمایی شما تحسین‌برانگیز است! 👏";
            else if (percentage >= 50) message = "خوب بود! می‌توانید بهتر هم باشید! 😊";
            else if (percentage >= 30) message = "نیاز به تمرین بیشتر دارید! 🎞️";
            else message = "نگران نباشید! دفعه بعد بهتر می‌شود! 💪";
            
            document.getElementById("final-message").textContent = message;
            
            // ذخیره نتیجه در رتبه بندی
            saveToLeaderboard();
            updateShareLinks(maxScore);
            updateLeaderboard();
        }

        function saveToLeaderboard() {
            const maxScore = selectedQuestions.length * 40;
            const percentage = Math.round((currentScore / maxScore) * 100);
            
            leaderboard.push({
                name: playerName,
                score: currentScore,
                percentage: percentage,
                count: selectedQuestions.length,
                category: selectedCategory,
                date: new Date().toLocaleDateString('fa-IR')
            });
            
            leaderboard.sort((a, b) => b.percentage - a.percentage || b.score - a.score);
            leaderboard = leaderboard.slice(0, 10);
            localStorage.setItem('cinemaQuizLeaderboard', JSON.stringify(leaderboard));
        }

        function updateShareLinks(maxScore) {
            const text = `من در بازی سینمازمون ${currentScore} از ${maxScore} امتیاز گرفتم! 🎬\n${window.location.href}`;
            const encodedText = encodeURIComponent(text);
            const url = encodeURIComponent(window.location.href);
            
            document.getElementById("telegram-share").href = `https://t.me/share/url?url=${url}&text=${encodedText}`;
            document.getElementById("whatsapp-share").href = `https://wa.me/?text=${encodedText}`;
            document.getElementById("twitter-share").href = `https://twitter.com/intent/tweet?text=${encodedText}`;
        }

        function updateLeaderboard() {
            const leaderboardList = document.getElementById("leaderboard-list");
            leaderboardList.innerHTML = "";
            
            if (leaderboard.length === 0) {
                leaderboardList.innerHTML = "<p>هنوز رکوردی ثبت نشده است!</p>";
                return;
            }
            
            leaderboard.forEach((player, index) => {
                const item = document.createElement("div");
                item.className = "leaderboard-item";
                item.innerHTML = `
                    <span>${index + 1}. ${player.name}</span>
                    <span>${player.percentage}% (${player.score}/${player.count * 40})</span>
                `;
                leaderboardList.appendChild(item);
            });
        }

        function restartGame() {
            document.getElementById("end-screen").classList.add("hidden");
            document.getElementById("name-screen").classList.remove("hidden");
            document.getElementById("name-input").value = "";
        }

        // بارگذاری اولیه لیست برترین‌ها
        updateLeaderboard();
    </script>
</body>
</html>
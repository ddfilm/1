<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/auth.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    // بررسی اعتبار کاربر
    $stmt = $conn->prepare("SELECT id, password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->bind_result($user_id, $hashed_password);
    $stmt->fetch();
    
    if ($user_id && password_verify($password, $hashed_password)) {
        $_SESSION['user_id'] = $user_id;
        header("Location: ../dashboard.php");
        exit();
    } else {
        $error = "نام کاربری یا رمز عبور اشتباه است";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>ورود به سیستم</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="login-container">
        <h2>ورود به سیستم</h2>
        
        <?php if ($error): ?>
            <div class="alert error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="post" action="">
            <div class="form-group">
                <label>نام کاربری:</label>
                <input type="text" name="username" required>
            </div>
            
            <div class="form-group">
                <label>رمز عبور:</label>
                <input type="password" name="password" required>
            </div>
            
            <button type="submit">ورود</button>
        </form>
        
        <p class="register-link">
            حساب کاربری ندارید؟ <a href="../register/">ثبت نام کنید</a>
        </p>
    </div>
</body>
</html>
<?php
require_once 'config.php';

function registerUser($email, $username, $password) {
    global $conn;
    
    // بررسی وجود کاربر
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? OR username = ?");
    $stmt->bind_param("ss", $email, $username);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        return "کاربری با این ایمیل یا نام کاربری وجود دارد";
    }
    $stmt->close();
    
    // هش کردن رمز عبور
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // ثبت کاربر جدید
    $stmt = $conn->prepare("INSERT INTO users (email, username, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $email, $username, $hashed_password);
    
    if ($stmt->execute()) {
        return true;
    } else {
        return "خطا در ثبت نام: " . $conn->error;
    }
}
?>
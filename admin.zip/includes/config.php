<?php
// اطلاعات اتصال به دیتابیس
define('DB_HOST', 'localhost');
define('DB_USER', 'pcekmkhd_hadi'); // نام کاربری دیتابیس
define('DB_PASS', 'Hadi6155Mehrimah1089'); // رمز عبور دیتابیس
define('DB_NAME', 'pcekmkhd_azmoon');  // نام دیتابیس

// ایجاد اتصال
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// بررسی اتصال
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
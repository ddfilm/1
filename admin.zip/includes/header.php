<?php
session_start();
?>
<!DOCTYPE html>
<html dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>سایت آزمون آنلاین</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazir-font@v30.1.0/dist/font-face.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <nav class="main-nav">
        <div class="nav-container">
            <a href="index.php" class="logo">آزمون آنلاین</a>
            
            <div class="nav-links">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> داشبورد</a>
                    <a href="game/start.php"><i class="fas fa-gamepad"></i> شروع بازی</a>
                    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> خروج</a>
                <?php else: ?>
                    <a href="register/"><i class="fas fa-user-plus"></i> ثبت نام</a>
                    <a href="login/"><i class="fas fa-sign-in-alt"></i> ورود</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
<footer>
    <div class="footer-content">
        <p>© ۱۴۰۲ سامانه آزمون آنلاین. تمام حقوق محفوظ است.</p>
        <div class="social-links">
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-telegram"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
        </div>
    </div>
</footer>
</body>
</html>
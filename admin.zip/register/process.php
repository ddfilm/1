<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    // اعتبارسنجی
    if (empty($email) || empty($username) || empty($password)) {
        $_SESSION['error'] = "لطفا تمام فیلدها را پر کنید";
        header("Location: index.php");
        exit();
    }
    
    if ($password !== $confirm_password) {
        $_SESSION['error'] = "رمز عبور و تکرار آن مطابقت ندارند";
        header("Location: index.php");
        exit();
    }
    
    // ثبت کاربر
    $result = registerUser($email, $username, $password);
    
    if ($result === true) {
        // ورود خودکار کاربر بعد از ثبت نام
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->bind_result($user_id);
        $stmt->fetch();
        $stmt->close();
        
        $_SESSION['user_id'] = $user_id;
        header("Location: ../dashboard.php");
        exit();
    } else {
        $_SESSION['error'] = $result;
        header("Location: index.php");
        exit();
    }
}
?>
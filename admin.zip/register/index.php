<?php 
session_start();
require_once '../includes/config.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    // اعتبارسنجی ساده
    if (empty($email) || empty($username) || empty($password)) {
        $error = "لطفا تمام فیلدها را پر کنید";
    } elseif ($password !== $confirm_password) {
        $error = "رمز عبور و تکرار آن مطابقت ندارند";
    } else {
        $result = registerUser($email, $username, $password);
        if ($result === true) {
            $success = "ثبت نام با موفقیت انجام شد!";
        } else {
            $error = $result;
        }
    }
}
?>
$error = isset($_SESSION['error']) ? $_SESSION['error'] : '';
unset($_SESSION['error']);
?>

<!DOCTYPE html>
<html dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>ثبت نام</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="register-container">
        <h2>فرم ثبت نام</h2>
        
        <?php if ($error): ?>
            <div class="alert error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="post" action="process.php">
        
        <?php if ($success): ?>
            <div class="alert success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <form method="post" action="">
            <div class="form-group">
                <label>آدرس ایمیل:</label>
                <input type="email" name="email" required>
                <small>لطفا با ایمیل معتبر ثبت نام کنید</small>
            </div>
            
            <div class="form-group">
                <label>نام کاربری:</label>
                <input type="text" name="username" required>
                <small>دیگران شما را با این نام می‌بینند</small>
            </div>
            
            <div class="form-group">
                <label>رمز عبور:</label>
                <input type="password" name="password" required>
            </div>
            
            <div class="form-group">
                <label>تکرار رمز عبور:</label>
                <input type="password" name="confirm_password" required>
            </div>
            
            <button type="submit">ثبت نام</button>
        </form>
        
        <p class="forgot-password">
            <a href="../forgot-password.php">فراموشی رمز عبور</a>
        </p>
    </div>
</body>
</html>
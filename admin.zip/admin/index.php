<?php
session_start();
// اعتبارسنجی ورود ادمین
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}

$questionsFile = 'questions.json';
$questions = file_exists($questionsFile) ? json_decode(file_get_contents($questionsFile), true) : [];

// پردازش فرم افزودن/ویرایش سوال
if (isset($_POST['save_question'])) {
    $correctAnswer = (int)$_POST['correct_answer'];
    $options = array_values(array_filter($_POST['options'])); // حذف گزینه‌های خالی و بازنشانی اندیس
    
    // اعتبارسنجی
    if ($correctAnswer < 0 || $correctAnswer >= count($options)) {
        $correctAnswer = 0;
    }

    $questionData = [
        'question' => trim($_POST['question']),
        'options' => $options,
        'answer' => $correctAnswer,
        'category' => $_POST['category'],
        'image' => $_POST['existing_image'] ?? ''
    ];

    // آپلود تصویر جدید
    if (!empty($_FILES['image']['name'])) {
        $uploadDir = '../pic/';
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        // حذف تصویر قبلی اگر وجود دارد
        if (!empty($questionData['image']) && file_exists('../' . $questionData['image'])) {
            unlink('../' . $questionData['image']);
        }
        
        $fileName = uniqid() . '_' . basename($_FILES['image']['name']);
        if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $fileName)) {
            $questionData['image'] = 'pic/' . $fileName;
        }
    }

    // اگر در حال ویرایش هستیم
    if (isset($_POST['edit_index']) && isset($questions[$_POST['edit_index']])) {
        $questions[$_POST['edit_index']] = $questionData;
    } else {
        $questions[] = $questionData;
    }
    
    file_put_contents($questionsFile, json_encode($questions, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    header('Location: index.php?success=1');
    exit;
}

// پردازش حذف سوال
if (isset($_POST['delete_question'])) {
    $index = (int)$_POST['delete_index'];
    if (isset($questions[$index])) {
        // حذف تصویر مرتبط اگر وجود دارد
        if (!empty($questions[$index]['image']) && file_exists('../' . $questions[$index]['image'])) {
            unlink('../' . $questions[$index]['image']);
        }
        array_splice($questions, $index, 1);
        file_put_contents($questionsFile, json_encode($questions, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    }
    header('Location: index.php');
    exit;
}

// دریافت سوال برای ویرایش
$editQuestion = null;
if (isset($_GET['edit'])) {
    $editIndex = (int)$_GET['edit'];
    if (isset($questions[$editIndex])) {
        $editQuestion = $questions[$editIndex];
        $editQuestion['index'] = $editIndex;
    }
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>پنل مدیریت سوالات</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #6e48aa;
            --primary-light: #9d50bb;
            --secondary: #ff7b25;
            --light: #f8f9fa;
            --dark: #343a40;
            --gray: #6c757d;
            --success: #28a745;
            --danger: #dc3545;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f5f5, #e9ecef);
            color: var(--dark);
            line-height: 1.6;
        }
        
        .container {
            max-width: 900px;
            margin: 30px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        h1, h2, h3 {
            color: var(--primary);
        }
        
        h1 {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--primary-light);
        }
        
        h2 {
            margin: 25px 0 15px;
            color: var(--secondary);
        }
        
        .success-message {
            background-color: rgba(40, 167, 69, 0.2);
            color: var(--success);
            padding: 10px 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border: 1px solid var(--success);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--primary);
        }
        
        input[type="text"],
        input[type="file"],
        select,
        textarea {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid #ced4da;
            border-radius: 5px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        
        input[type="text"]:focus,
        select:focus,
        textarea:focus {
            border-color: var(--primary);
            outline: none;
            box-shadow: 0 0 0 3px rgba(110, 72, 170, 0.25);
        }
        
        .option-input {
            margin-bottom: 10px;
            position: relative;
        }
        
        .option-input input {
            padding-right: 40px;
        }
        
        .remove-option {
            position: absolute;
            left: 10px;
            top: 50%;
            transform: translateY(-50%);
            background: var(--danger);
            color: white;
            border: none;
            width: 25px;
            height: 25px;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .btn {
            display: inline-block;
            padding: 10px 20px;
            border-radius: 5px;
            font-weight: 600;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
            border: none;
            font-size: 16px;
        }
        
        .btn-primary {
            background-color: var(--primary);
            color: white;
        }
        
        .btn-primary:hover {
            background-color: var(--primary-light);
            transform: translateY(-2px);
        }
        
        .btn-secondary {
            background-color: var(--secondary);
            color: white;
        }
        
        .btn-secondary:hover {
            opacity: 0.9;
            transform: translateY(-2px);
        }
        
        .btn-danger {
            background-color: var(--danger);
            color: white;
        }
        
        .btn-danger:hover {
            opacity: 0.9;
            transform: translateY(-2px);
        }
        
        .btn-sm {
            padding: 5px 10px;
            font-size: 14px;
        }
        
        .add-option {
            background-color: var(--success);
            color: white;
            margin-top: 5px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.05);
        }
        
        th, td {
            padding: 12px 15px;
            text-align: right;
            border-bottom: 1px solid #dee2e6;
        }
        
        th {
            background-color: var(--primary);
            color: white;
            font-weight: 600;
        }
        
        tr:nth-child(even) {
            background-color: rgba(110, 72, 170, 0.05);
        }
        
        tr:hover {
            background-color: rgba(110, 72, 170, 0.1);
        }
        
        .actions {
            display: flex;
            gap: 5px;
        }
        
        .image-preview {
            max-width: 100px;
            max-height: 100px;
            border-radius: 5px;
            margin-top: 10px;
            display: block;
        }
        
        .no-image {
            color: var(--gray);
            font-style: italic;
        }
        
        .form-actions {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }
        
        @media (max-width: 768px) {
            .container {
                padding: 15px;
                margin: 15px;
            }
            
            th, td {
                padding: 8px 10px;
            }
            
            .actions {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1><i class="fas fa-film"></i> پنل مدیریت سوالات سینمایی</h1>
        
        <?php if (isset($_GET['success'])): ?>
            <div class="success-message">
                <i class="fas fa-check-circle"></i> سوال با موفقیت ذخیره شد!
            </div>
        <?php endif; ?>

        <h2><?= $editQuestion ? 'ویرایش سوال' : 'افزودن سوال جدید' ?></h2>
        <form method="post" enctype="multipart/form-data">
            <?php if ($editQuestion): ?>
                <input type="hidden" name="edit_index" value="<?= $editQuestion['index'] ?>">
                <input type="hidden" name="existing_image" value="<?= htmlspecialchars($editQuestion['image'] ?? '') ?>">
            <?php endif; ?>
            
            <div class="form-group">
                <label for="question"><i class="fas fa-question-circle"></i> متن سوال:</label>
                <input type="text" id="question" name="question" required 
                       value="<?= htmlspecialchars($editQuestion['question'] ?? '') ?>">
            </div>
            
            <div class="form-group">
                <label><i class="fas fa-list-ol"></i> گزینه‌ها:</label>
                <div id="options-container">
                    <?php 
                    $options = $editQuestion['options'] ?? ['', '', '', ''];
                    foreach ($options as $i => $option): 
                    ?>
                        <div class="option-input">
                            <input type="text" name="options[]" class="option-input" 
                                   placeholder="گزینه <?= $i + 1 ?>" 
                                   value="<?= htmlspecialchars($option) ?>"
                                   <?= $i < 2 ? 'required' : '' ?>>
                            <?php if ($i >= 2): ?>
                                <button type="button" class="remove-option" onclick="removeOption(this)">
                                    <i class="fas fa-times"></i>
                                </button>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="btn add-option" onclick="addOption()">
                    <i class="fas fa-plus"></i> افزودن گزینه
                </button>
            </div>
            
            <div class="form-group">
                <label for="correct_answer"><i class="fas fa-check-circle"></i> پاسخ صحیح:</label>
                <select id="correct_answer" name="correct_answer" required>
                    <?php foreach ($options as $i => $option): ?>
                        <?php if (!empty($option)): ?>
                            <option value="<?= $i ?>" 
                                <?= ($editQuestion && $editQuestion['answer'] == $i) ? 'selected' : '' ?>>
                                گزینه <?= $i + 1 ?>: <?= htmlspecialchars(mb_substr($option, 0, 20)) ?>...
                            </option>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label for="category"><i class="fas fa-tags"></i> دسته‌بندی:</label>
                <select id="category" name="category" required>
                    <option value="all" <?= ($editQuestion && $editQuestion['category'] == 'all') ? 'selected' : '' ?>>همه دسته‌ها</option>
                    <option value="iran" <?= ($editQuestion && $editQuestion['category'] == 'iran') ? 'selected' : '' ?>>سینمای ایران</option>
                    <option value="foreign" <?= ($editQuestion && $editQuestion['category'] == 'foreign') ? 'selected' : '' ?>>سینمای خارج</option>
                </select>
            </div>
            
            <div class="form-group">
                <label><i class="fas fa-image"></i> تصویر (اختیاری):</label>
                <input type="file" name="image" accept="image/*">
                
                <?php if ($editQuestion && !empty($editQuestion['image'])): ?>
                    <div style="margin-top: 10px;">
                        <span>تصویر فعلی:</span>
                        <img src="../<?= htmlspecialchars($editQuestion['image']) ?>" class="image-preview">
                    </div>
                <?php elseif ($editQuestion): ?>
                    <div class="no-image">تصویری انتخاب نشده است</div>
                <?php endif; ?>
            </div>
            
            <div class="form-actions">
                <button type="submit" name="save_question" class="btn btn-primary">
                    <i class="fas fa-save"></i> <?= $editQuestion ? 'ذخیره تغییرات' : 'ذخیره سوال' ?>
                </button>
                
                <?php if ($editQuestion): ?>
                    <a href="index.php" class="btn btn-danger">
                        <i class="fas fa-times"></i> انصراف
                    </a>
                <?php endif; ?>
            </div>
        </form>

        <h2 style="margin-top: 40px;"><i class="fas fa-list"></i> لیست سوالات موجود</h2>
        <table>
            <thead>
                <tr>
                    <th>سوال</th>
                    <th>دسته‌بندی</th>
                    <th>تصویر</th>
                    <th>عملیات</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($questions)): ?>
                    <tr>
                        <td colspan="4" style="text-align: center;">هیچ سوالی ثبت نشده است</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($questions as $index => $q): ?>
                    <tr>
                        <td><?= htmlspecialchars(mb_substr($q['question'], 0, 30)) ?>...</td>
                        <td>
                            <?= match($q['category']) {
                                'iran' => '<span style="color: var(--primary);">سینمای ایران</span>',
                                'foreign' => '<span style="color: var(--secondary);">سینمای خارج</span>',
                                default => 'همه دسته‌ها'
                            } ?>
                        </td>
                        <td>
                            <?php if (!empty($q['image'])): ?>
                                <i class="fas fa-check-circle" style="color: var(--success);"></i>
                            <?php else: ?>
                                <i class="fas fa-times-circle" style="color: var(--danger);"></i>
                            <?php endif; ?>
                        </td>
                        <td class="actions">
                            <a href="index.php?edit=<?= $index ?>" class="btn btn-secondary btn-sm">
                                <i class="fas fa-edit"></i> ویرایش
                            </a>
                            <form method="post" style="display: inline;">
                                <input type="hidden" name="delete_index" value="<?= $index ?>">
                                <button type="submit" name="delete_question" class="btn btn-danger btn-sm" 
                                        onclick="return confirm('آیا از حذف این سوال مطمئن هستید؟')">
                                    <i class="fas fa-trash"></i> حذف
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <script>
        function addOption() {
            const container = document.getElementById('options-container');
            const count = container.children.length + 1;
            if (count <= 6) {
                const div = document.createElement('div');
                div.className = 'option-input';
                div.innerHTML = `
                    <input type="text" name="options[]" placeholder="گزینه ${count}">
                    <button type="button" class="remove-option" onclick="removeOption(this)">
                        <i class="fas fa-times"></i>
                    </button>
                `;
                container.appendChild(div);
                updateAnswerOptions();
            }
        }
        
        function removeOption(button) {
            const container = button.closest('.option-input');
            container.remove();
            updateAnswerOptions();
        }
        
        function updateAnswerOptions() {
            const select = document.getElementById('correct_answer');
            const options = document.querySelectorAll('input[name="options[]"]');
            
            // ذخیره مقدار انتخاب شده فعلی
            const selectedValue = select.value;
            
            // پاک کردن گزینه‌های فعلی
            select.innerHTML = '';
            
            // اضافه کردن گزینه‌های جدید
            options.forEach((input, index) => {
                if (input.value.trim() !== '') {
                    const option = document.createElement('option');
                    option.value = index;
                    option.textContent = `گزینه ${index + 1}: ${input.value.substring(0, 20)}...`;
                    select.appendChild(option);
                }
            });
            
            // بازگرداندن مقدار انتخاب شده قبلی اگر هنوز معتبر است
            if (selectedValue < select.options.length) {
                select.value = selectedValue;
            }
        }
        
        // بروزرسانی خودکار گزینه‌های پاسخ هنگام تغییر گزینه‌ها
        document.addEventListener('DOMContentLoaded', function() {
            const optionsContainer = document.getElementById('options-container');
            optionsContainer.addEventListener('input', function(e) {
                if (e.target.name === 'options[]') {
                    updateAnswerOptions();
                }
            });
        });
    </script>
</body>
</html>
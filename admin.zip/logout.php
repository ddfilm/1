<?php
session_start();

// حذف تمام داده‌های session
$_SESSION = array();

// اگر کوکی session استفاده می‌شود، آن را حذف کنید
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// نابودی session
session_destroy();

// هدایت به صفحه اصلی
header("Location: ../index.html");
exit();
?>
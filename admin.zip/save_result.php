<?php
header('Content-Type: application/json');
require_once 'includes/config.php';

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['user_id']) || !isset($data['score']) || !isset($data['question_count'])) {
    echo json_encode(['status' => 'error', 'message' => 'داده‌های ناقص']);
    exit;
}

try {
    $stmt = $conn->prepare("INSERT INTO game_results (user_id, score, question_count) VALUES (?, ?, ?)");
    $stmt->bind_param("iii", $data['user_id'], $data['score'], $data['question_count']);
    $stmt->execute();
    
    echo json_encode(['status' => 'success', 'message' => 'نتایج با موفقیت ذخیره شد']);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'خطا در ذخیره نتایج: ' . $e->getMessage()]);
}
?>